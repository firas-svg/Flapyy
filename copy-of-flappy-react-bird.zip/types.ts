
export enum GameStatus {
  WELCOME = 'WELCOME',
  START = 'START',
  PLAYING = 'PLAYING',
  GAME_OVER = 'GAME_OVER'
}

export enum Difficulty {
  EASY = 'EASY',
  MEDIUM = 'MEDIUM',
  HARD = 'HARD'
}

export interface PipeData {
  id: number;
  x: number;
  topHeight: number; // Height of the top pipe
  passed: boolean;
  gap: number; // The vertical gap size for this specific pipe
}

export interface ParticleData {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  size: number;
}

export interface GameState {
  status: GameStatus;
  score: number;
  bestScore: number;
}

// --- SHOP TYPES ---

export type ItemType = 'SKIN' | 'ACCESSORY' | 'THEME' | 'CONSUMABLE';

export interface ThemeColors {
  pipeBase: string;
  pipeBorder: string; // Darker shade for outlines
  pipeRim: string; // Slightly lighter for 3D effect
  bgGradientFrom: string;
  bgGradientTo: string;
  groundBase: string;
  groundBorder: string;
  groundTop: string;
}

export interface ShopItem {
  id: string;
  name: string;
  type: ItemType;
  price: number;
  // For skins, this maps to color overrides
  skinColors?: {
    body: string;
    belly: string;
    wing: string;
  };
  // For themes
  themeColors?: ThemeColors;
  // For consumables
  duration?: number; // duration in ms
  description?: string;
}

export interface PlayerProgress {
  totalXP: number;
  ownedItems: string[]; // List of IDs
  equippedSkin: string;
  equippedAccessory: string;
  equippedTheme: string;
  activeBoostEndTime?: number; // Timestamp when boost expires
}
