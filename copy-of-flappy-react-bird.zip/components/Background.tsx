
import React from 'react';
import { GROUND_HEIGHT } from '../constants';
import { ThemeColors } from '../types';

interface BackgroundProps {
    theme: ThemeColors;
}

export const Background: React.FC<BackgroundProps> = ({ theme }) => {
  return (
    <div 
        className="absolute inset-0 z-0 w-full h-full overflow-hidden transition-colors duration-700"
        style={{
            background: `linear-gradient(to bottom, ${theme.bgGradientFrom}, ${theme.bgGradientTo})`
        }}
    >
      
      {/* Cloud 1 - Slow, Distant */}
      <div className="absolute top-[15%] w-[100px] h-6 opacity-60 animate-[cloudDrift_45s_linear_infinite] delay-neg-15">
        <div className="w-16 h-6 bg-white rounded-full absolute top-0 left-0"></div>
        <div className="w-10 h-10 bg-white rounded-full absolute -top-5 left-4"></div>
        <div className="w-12 h-8 bg-white rounded-full absolute -top-2 left-8"></div>
      </div>

      {/* Cloud 2 - Medium Speed */}
      <div className="absolute top-[25%] scale-75 opacity-70 animate-[cloudDrift_30s_linear_infinite] delay-neg-5">
        <div className="w-20 h-8 bg-white rounded-full absolute top-0 left-0"></div>
        <div className="w-12 h-12 bg-white rounded-full absolute -top-6 left-4"></div>
      </div>

      {/* Cloud 3 - Fast, Closer */}
      <div className="absolute top-[10%] scale-110 opacity-80 animate-[cloudDrift_25s_linear_infinite] delay-neg-10">
        <div className="w-24 h-8 bg-white rounded-full absolute top-0 left-0"></div>
        <div className="w-14 h-14 bg-white rounded-full absolute -top-8 left-5"></div>
        <div className="w-12 h-10 bg-white rounded-full absolute -top-4 right-2"></div>
      </div>
      
      {/* Ground Layer */}
      <div 
        className="absolute bottom-0 z-20 w-full border-t-4 overflow-hidden transition-colors duration-500"
        style={{ 
            height: GROUND_HEIGHT,
            backgroundColor: theme.groundBase,
            borderColor: theme.groundBorder
        }}
      >
        {/* Define animation keyframes locally since the skyline div was removed */}
        <style dangerouslySetInnerHTML={{__html: `
          @keyframes slideBg {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
          }
        `}} />

        {/* Grass Strip */}
        <div 
            className="w-full h-3 border-b-2"
            style={{ 
                backgroundColor: theme.groundTop,
                borderColor: theme.groundBorder
            }}
        ></div>
        {/* Ground Pattern - Animated via CSS for simple parallax effect feeling */}
        <div 
            className="w-[200%] h-full flex animate-[slideBg_3s_linear_infinite]" 
            style={{
                backgroundImage: `linear-gradient(45deg, rgba(0,0,0,0.1) 25%, transparent 25%, transparent 75%, rgba(0,0,0,0.1) 75%, rgba(0,0,0,0.1)), linear-gradient(45deg, rgba(0,0,0,0.1) 25%, transparent 25%, transparent 75%, rgba(0,0,0,0.1) 75%, rgba(0,0,0,0.1))`,
                backgroundSize: '20px 20px',
                backgroundPosition: '0 0, 10px 10px',
            }}
        ></div>
      </div>
    </div>
  );
};
