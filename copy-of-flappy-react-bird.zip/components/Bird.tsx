
import React, { useMemo } from 'react';
import { BIRD_SIZE, SHOP_ITEMS } from '../constants';

interface BirdProps {
  y?: number;
  rotation?: number;
  skinId?: string;
  accessoryId?: string;
  isStatic?: boolean;
}

export const Bird: React.FC<BirdProps> = ({ 
  y = 0, 
  rotation = 0, 
  skinId = 'skin_default', 
  accessoryId = 'acc_none',
  isStatic = false 
}) => {
  
  // Resolve Skin Colors
  const colors = useMemo(() => {
    const item = SHOP_ITEMS.find(i => i.id === skinId);
    return item?.skinColors || { body: '#FACC15', belly: '#FEF08A', wing: '#ffffff' };
  }, [skinId]);

  const containerStyle: React.CSSProperties = isStatic ? {
     width: BIRD_SIZE,
     height: BIRD_SIZE,
     transform: `rotate(${rotation}deg)`
  } : {
     top: y,
     width: BIRD_SIZE,
     height: BIRD_SIZE,
     transform: `rotate(${rotation}deg)`,
     transition: 'transform 0.1s ease-out'
  };

  const containerClass = isStatic 
    ? "relative inline-block"
    : "absolute left-8 z-20 will-change-transform";

  return (
    <div 
      className={containerClass}
      style={containerStyle}
    >
      <svg
        viewBox="0 0 40 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-lg"
      >
        {/* Body */}
        <path
          d="M34 16C34 16 32 10 26 10H14C8 10 4 16 4 20C4 26 8 30 14 30H28"
          fill={colors.body}
          stroke="black"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        
        {/* White Belly Patch */}
        <path
          d="M26 26C24 26 22 30 14 30C10 30 8 28 6 24"
          stroke="black"
          strokeWidth="2.5"
          fill={colors.belly}
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Eye */}
        <circle cx="28" cy="16" r="6" fill="white" stroke="black" strokeWidth="2.5" />
        <circle cx="30" cy="16" r="2" fill="black" />

        {/* Wing */}
        <path
          d="M10 20C10 20 12 16 18 18C22 19 22 22 18 24C12 25 10 20 10 20Z"
          fill={colors.wing}
          stroke="black"
          strokeWidth="2.5"
          strokeLinejoin="round"
        />

        {/* Beak Lower */}
        <path
          d="M28 26L36 26C36 26 38 28 36 30C34 32 30 30 28 30"
          fill="#F97316" // orange-500
          stroke="black"
          strokeWidth="2.5"
          strokeLinejoin="round"
        />
        {/* Beak Upper */}
        <path
          d="M28 26L36 26C36 26 38 24 36 22C34 20 30 22 28 26"
          fill="#F97316" // orange-500
          stroke="black"
          strokeWidth="2.5"
          strokeLinejoin="round"
        />

        {/* --- ACCESSORIES --- */}
        
        {/* Sunglasses */}
        {accessoryId === 'acc_sunglasses' && (
           <g transform="translate(24, 12) scale(0.8)">
             <path d="M0 4 H14" stroke="black" strokeWidth="2" />
             <rect x="0" y="2" width="6" height="4" fill="black" />
             <rect x="8" y="2" width="6" height="4" fill="black" />
           </g>
        )}

        {/* Crown */}
        {accessoryId === 'acc_crown' && (
           <path 
             d="M14 10 L14 4 L18 8 L22 4 L26 8 L30 4 L30 10" 
             fill="#FFD700" 
             stroke="black" 
             strokeWidth="1.5"
             strokeLinejoin="round"
             transform="translate(-2, -4)"
           />
        )}

        {/* Halo */}
        {accessoryId === 'acc_halo' && (
            <ellipse cx="22" cy="6" rx="8" ry="2" stroke="#FFD700" strokeWidth="2" fill="none" />
        )}

        {/* Top Hat */}
        {accessoryId === 'acc_tophat' && (
            <g transform="translate(14, 2)">
                <rect x="0" y="6" width="16" height="2" fill="#222" stroke="black" strokeWidth="1"/>
                <rect x="3" y="0" width="10" height="6" fill="#222" stroke="black" strokeWidth="1"/>
                <rect x="3" y="4" width="10" height="2" fill="#C0392B"/>
            </g>
        )}

      </svg>
    </div>
  );
};
