
import React from 'react';
import { PIPE_WIDTH, GROUND_HEIGHT } from '../constants';
import { ThemeColors } from '../types';

interface PipeProps {
  x: number;
  topHeight: number;
  gameHeight: number;
  gap: number;
  theme: ThemeColors;
}

export const Pipe: React.FC<PipeProps> = ({ x, topHeight, gameHeight, gap, theme }) => {
  const bottomPipeHeight = gameHeight - GROUND_HEIGHT - topHeight - gap;

  // Use translate3d for GPU acceleration
  const style = {
    transform: `translate3d(${x}px, 0, 0)`,
    width: PIPE_WIDTH,
    willChange: 'transform' // Hint to browser to optimize
  } as const;

  const borderWidth = '2px';
  const borderColor = theme.pipeBorder; // Classic dark outline

  // Classic sprite gradient style:
  // Dark edge -> Base Color -> Highlight Strip -> Base Color -> Dark Edge
  // This creates the 2D cylindrical look
  const pipeGradient = `linear-gradient(90deg, 
      ${theme.pipeBase} 0%, 
      ${theme.pipeBase} 10%, 
      ${theme.pipeRim} 10%, 
      ${theme.pipeRim} 20%, 
      ${theme.pipeBase} 20%, 
      ${theme.pipeBase} 95%, 
      rgba(0,0,0,0.2) 95%, 
      rgba(0,0,0,0.2) 100%
  )`;

  return (
    <>
      {/* Top Pipe */}
      <div 
        className="absolute top-0 left-0 flex flex-col justify-end z-10"
        style={{ 
          ...style,
          height: topHeight,
        }}
      >
        {/* Pipe Body (Top) */}
        <div 
          className="w-full flex-1 relative"
          style={{ 
            background: pipeGradient,
            borderLeft: `${borderWidth} solid ${borderColor}`,
            borderRight: `${borderWidth} solid ${borderColor}`,
            // No bottom border here, connects to cap
          }}
        ></div>
        
        {/* Pipe Cap (Rim) - Top */}
        <div 
          className="h-6 relative z-20"
          style={{ 
            width: '108%', // Cap is wider
            marginLeft: '-4%', // Center the cap
            background: pipeGradient,
            border: `${borderWidth} solid ${borderColor}`,
            borderRadius: '2px'
          }}
        />
      </div>

      {/* Bottom Pipe */}
      <div 
        className="absolute left-0 flex flex-col justify-start z-10"
        style={{ 
          ...style,
          bottom: GROUND_HEIGHT,
          height: bottomPipeHeight,
        }}
      >
        {/* Pipe Cap (Rim) - Bottom */}
        <div 
            className="h-6 relative z-20"
            style={{ 
                width: '108%', // Cap is wider
                marginLeft: '-4%', // Center the cap
                background: pipeGradient,
                border: `${borderWidth} solid ${borderColor}`,
                borderRadius: '2px'
            }}
        />

        {/* Pipe Body (Bottom) */}
        <div 
          className="w-full flex-1 relative"
          style={{ 
            background: pipeGradient,
            borderLeft: `${borderWidth} solid ${borderColor}`,
            borderRight: `${borderWidth} solid ${borderColor}`,
            // No top border here, connects to cap
          }}
        ></div>
      </div>
    </>
  );
};
