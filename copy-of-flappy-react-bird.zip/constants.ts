
import { Difficulty, ShopItem } from './types';

// Static Layout Constants
export const PIPE_WIDTH = 52; // Slightly narrower to match classic aspect ratio better
export const BIRD_SIZE = 34; // Slightly smaller bird
export const BIRD_X_POSITION = 80; // Fixed X position for the bird
export const GROUND_HEIGHT = 112; // Adjusted for proportions

// Boundaries
export const GAME_WIDTH = window.innerWidth > 448 ? 448 : window.innerWidth;
export const GAME_HEIGHT = window.innerHeight;
export const CEILING_LIMIT = -200; // Allow bird to go slightly above screen before resetting logic if needed

// Game Physics & Difficulty Settings
export const DIFFICULTY_SETTINGS = {
  [Difficulty.EASY]: {
    gravity: 0.4,
    jumpStrength: -6.5,
    pipeSpeed: 2.8,
    pipeGap: 190,
  },
  [Difficulty.MEDIUM]: {
    gravity: 0.55,
    jumpStrength: -7.5,
    pipeSpeed: 3.2,
    pipeGap: 160,
  },
  [Difficulty.HARD]: {
    gravity: 0.7,
    jumpStrength: -8.5,
    pipeSpeed: 4.0,
    pipeGap: 140,
  }
};

// --- SHOP INVENTORY ---

export const SHOP_ITEMS: ShopItem[] = [
  // --- SKINS ---
  {
    id: 'skin_default',
    name: 'Classic',
    type: 'SKIN',
    price: 0,
    skinColors: { body: '#FACC15', belly: '#FEF08A', wing: '#ffffff' } // Yellow
  },
  {
    id: 'skin_red',
    name: 'Red Bird',
    type: 'SKIN',
    price: 50,
    skinColors: { body: '#ef4444', belly: '#fecaca', wing: '#ffffff' }
  },
  {
    id: 'skin_blue',
    name: 'Blue Jay',
    type: 'SKIN',
    price: 100,
    skinColors: { body: '#3b82f6', belly: '#bfdbfe', wing: '#93c5fd' }
  },
  {
    id: 'skin_ninja',
    name: 'Ninja',
    type: 'SKIN',
    price: 300,
    skinColors: { body: '#333333', belly: '#555555', wing: '#1a1a1a' }
  },
  {
    id: 'skin_gold',
    name: 'Golden',
    type: 'SKIN',
    price: 1000,
    skinColors: { body: '#FFD700', belly: '#FFF8DC', wing: '#DAA520' }
  },

  // --- ACCESSORIES ---
  {
    id: 'acc_none',
    name: 'No Item',
    type: 'ACCESSORY',
    price: 0
  },
  {
    id: 'acc_sunglasses',
    name: 'Cool Shades',
    type: 'ACCESSORY',
    price: 75
  },
  {
    id: 'acc_crown',
    name: 'King Crown',
    type: 'ACCESSORY',
    price: 250
  },
  {
    id: 'acc_halo',
    name: 'Angel Halo',
    type: 'ACCESSORY',
    price: 500
  },
  {
    id: 'acc_tophat',
    name: 'Gentleman',
    type: 'ACCESSORY',
    price: 150
  },

  // --- THEMES ---
  {
    id: 'theme_day',
    name: 'Daylight',
    type: 'THEME',
    price: 0,
    themeColors: {
      pipeBase: '#73bf2e', // Classic Green
      pipeBorder: '#553000', // Dark brownish outline
      pipeRim: '#bbf276', // Lighter highlight
      bgGradientFrom: '#4ec0ca',
      bgGradientTo: '#4ec0ca', // Flat blue
      groundBase: '#ded895',
      groundBorder: '#5d3714',
      groundTop: '#73bf2e'
    }
  },
  {
    id: 'theme_night',
    name: 'Midnight',
    type: 'THEME',
    price: 200,
    themeColors: {
      pipeBase: '#436034', // Darker green
      pipeBorder: '#1a2614', 
      pipeRim: '#5e854a', 
      bgGradientFrom: '#1e1b4b',
      bgGradientTo: '#312e81',
      groundBase: '#3f3f46',
      groundBorder: '#18181b',
      groundTop: '#375726'
    }
  },
  {
    id: 'theme_candy',
    name: 'Candy Land',
    type: 'THEME',
    price: 500,
    themeColors: {
      pipeBase: '#ec4899', 
      pipeBorder: '#831843', 
      pipeRim: '#fbcfe8',
      bgGradientFrom: '#f9a8d4',
      bgGradientTo: '#fce7f3',
      groundBase: '#fcd34d',
      groundBorder: '#b45309',
      groundTop: '#f472b6'
    }
  },
  {
    id: 'theme_lava',
    name: 'Volcano',
    type: 'THEME',
    price: 800,
    themeColors: {
      pipeBase: '#b91c1c', 
      pipeBorder: '#450a0a', 
      pipeRim: '#ef4444', 
      bgGradientFrom: '#450a0a', 
      bgGradientTo: '#7f1d1d', 
      groundBase: '#292524', 
      groundBorder: '#0c0a09', 
      groundTop: '#ea580c' 
    }
  },

  // --- CONSUMABLES (BOOSTS) ---
  {
    id: 'boost_15m',
    name: '2x XP (15m)',
    type: 'CONSUMABLE',
    price: 150,
    duration: 15 * 60 * 1000,
    description: "Earn double XP for 15 minutes."
  },
  {
    id: 'boost_1h',
    name: '2x XP (1h)',
    type: 'CONSUMABLE',
    price: 500,
    duration: 60 * 60 * 1000,
    description: "Earn double XP for 1 hour."
  }
];
